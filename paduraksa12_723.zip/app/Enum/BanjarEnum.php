<?php

namespace App\Enum;

enum BanjarEnum: string
{
    case kangin = 'kangin';
    case langui = 'langui';
}

<?php

namespace App\Livewire;

use Livewire\Component;

class TentangLaporan extends Component
{
    public function render()
    {
        return view('livewire.tentang-laporan');
    }
}

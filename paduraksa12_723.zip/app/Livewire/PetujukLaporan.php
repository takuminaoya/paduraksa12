<?php

namespace App\Livewire;

use Livewire\Component;

class PetujukLaporan extends Component
{
    public function render()
    {
        return view('livewire.petujuk-laporan');
    }
}

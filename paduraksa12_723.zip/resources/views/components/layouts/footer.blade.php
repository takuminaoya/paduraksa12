<section id="footer" class="flex flex-row justify-center">
    <div class="container w-fit text-center pt-30 mb-10">
        <div class="grid lg:grid-cols-4 gap-5 mb-2">
            <a href="#" class="text-gray-500 font-bold hover:underline">PRIVACY</a>
            <a href="#" class="text-gray-500 font-bold hover:underline">BERANDA</a>
            <a href="#" class="text-gray-500 font-bold hover:underline">BLOG</a>
            <a href="#" class="text-gray-500 font-bold hover:underline">TENTANG KAMI</a>
        </div>
        <p>Copyright {{ date('Y') }}. Pemerintahan Desa Ungasan & Kayana Creative. Hak cipta dilindungi
            Undang-Undang.</p>
    </div>
</section>

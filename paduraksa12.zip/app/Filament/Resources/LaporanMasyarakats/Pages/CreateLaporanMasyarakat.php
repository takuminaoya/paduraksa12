<?php

namespace App\Filament\Resources\LaporanMasyarakats\Pages;

use App\Filament\Resources\LaporanMasyarakats\LaporanMasyarakatResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLaporanMasyarakat extends CreateRecord
{
    protected static string $resource = LaporanMasyarakatResource::class;
}
